import type { Budget, Category, DataService, Tx, Account, Profile } from './types';
import { store } from './store';
const DB_KEY = 'ep_sqlite_db';
function getDb(): Map<string, any> { try { const data = store.get(DB_KEY); return data ? new Map(JSON.parse(data)) : new Map(); } catch { return new Map(); } }
function setDb(db: Map<string, any>) { try { store.set(DB_KEY, JSON.stringify([...db.entries()])); } catch {} }
async function supabaseFetch<T>(endpoint: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`https://zfmwtexiyxjdmwybecfv.supabase.com/rest/v1${endpoint}`, {
    headers: { 'apikey': 'sb_publishable_1SeNDrQMEddymPbqozZ9EQ_kAZ-vvUP', 'Authorization': 'Bearer sb_publishable_1SeNDrQMEddymPbqozZ9EQ_kAZ-vvUP', 'Content-Type': 'application/json', ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) { const txt = await res.text(); throw new Error(`Supabase error ${res.status}: ${txt}`); }
  return res.json() as Promise<T>;
}
export const service: DataService = {
  demo: false,
async signOut(): Promise<void> {
    await supabaseFetch('/auth/v1/signout', { method: 'POST' });
    store.del('ep_session'); store.del('ep_email');
  },
  async hasSession(): Promise<boolean> { return store.get('ep_session') === '1'; },
  async signIn(email: string, password: string, remember: boolean): Promise<void> {
    await supabaseFetch('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email, password }) });
    store.set('ep_session', '1'); store.set('ep_email', email);
    if (!remember) { /* session-only token */ }
  },
  async resetPassword(email: string): Promise<void> {
    await supabaseFetch('/auth/v1/recovery', { method: 'POST', body: JSON.stringify({ email }) });
  },
  async biometric(): Promise<void> { await this.signIn('demo@test.com', 'password', false); },
  async listTransactions(): Promise<Tx[]> {
    const db = getDb(); const rows: Tx[] = [];
    for (const [key, row] of db) {
      rows.push({ id: row.id || key, dedupeKey: row.dedupeKey || '', source: row.source || 'mpesa', type: row.type || 'paid', direction: row.direction || 'out', amount: row.amount || 0, fee: row.fee || 0, counterparty: row.counterparty || null, categoryId: row.categoryId || null, balanceAfter: row.balanceAfter || null, occurredAt: row.occurredAt || '', relatedRef: row.relatedRef || null, transferGroup: row.transferGroup || null, rawText: row.rawText || '', synced: row.synced !== undefined ? row.synced : true });
    }
    return rows.sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
  },
  async getProfile(): Promise<Profile> {
    const email = store.get('ep_email') || 'user@example.com'; const name = email.split('@')[0].replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    return { name, email };
  },
  async listAccounts(): Promise<Account[]> {
    return [
      { id: 'mpesa', source: 'mpesa', name: 'M-Pesa', sub: 'Personal wallet', balance: null, manual: false },
      { id: 'coop', source: 'coop', name: 'Co-op Bank', sub: 'Everyday account', balance: null, manual: false },
    ];
  },
  async listCategories(): Promise<Category[]> {
    const defaults = [{ id: 'groceries', name: 'Food & groceries', color: '#8FD400' }, { id: 'eating', name: 'Eating out', color: '#F59E0B' }, { id: 'transport', name: 'Transport & fuel', color: '#7C3AED' }, { id: 'utilities', name: 'Utilities', color: '#0EA5A0' }, { id: 'airtime', name: 'Airtime & data', color: '#E879F9' }, { id: 'rent', name: 'Rent & housing', color: '#60A5FA' }, { id: 'people', name: 'Sent to people', color: '#FB7185' }, { id: 'income', name: 'Income', color: '#65A30D' }];
    const db = getDb(); const categories: Category[] = [];
    for (const [key, row] of db) { if (row.type === 'category') { categories.push({ id: key, name: row.name, color: row.color || '#6366f1' }); } }
    return categories.length > 0 ? categories : defaults;
  },
  async setCategory(txId: string, categoryId: string | null): Promise<void> {
    const db = getDb(); const row = db.get(txId);
    if (row) { row.categoryId = categoryId; row.synced = false; setDb(db); }
  },
  async listBudgets(): Promise<Budget[]> {
    const defaults = [{ categoryId: 'groceries', limit: 1500000 }, { categoryId: 'transport', limit: 600000 }, { categoryId: 'eating', limit: 500000 }, { categoryId: 'utilities', limit: 400000 }];
    const db = getDb(); const budgets: Budget[] = [];
    for (const [key, row] of db) { if (row.type === 'budget') { budgets.push({ categoryId: row.categoryId, limit: row.limit }); } }
    return budgets.length > 0 ? budgets : defaults;
  },
  async saveBudget(b: Budget): Promise<void> {
    const db = getDb(); const exists = Array.from(db.keys()).some(key => { const r = db.get(key); return r.type === 'budget' && r.categoryId === b.categoryId && r.limit === b.limit; });
    if (exists) { for (const [key, r] of db) { if (r.type === 'budget' && r.categoryId === b.categoryId) { r.limit = b.limit; setDb(db); return; } } }
    else { const key = `budget:${b.categoryId}:${b.limit}`; db.set(key, { type: 'budget', categoryId: b.categoryId, limit: b.limit }); setDb(db); }
  },
  async removeBudget(categoryId: string): Promise<void> {
    const db = getDb(); const keys: string[] = [];
    for (const [key, row] of db) { if (row.type === 'budget' && row.categoryId === categoryId) keys.push(key); }
    for (const k of keys) db.delete(k); setDb(db);
  },
  async setManualBalance(accountId: string, balance: number | null): Promise<void> {
    if (accountId !== 'coop') return; const db = getDb();
    if (balance !== null) { db.set('coop:manualBalance', { type: 'manualBalance', balance }); } else { db.delete('coop:manualBalance'); }
    setDb(db);
  },
  async saveRule(counterparty: string, categoryId: string): Promise<void> {
    const db = getDb(); const key = `rule:${counterparty}:${categoryId}`;
    db.set(key, { type: 'rule', counterparty, categoryId }); setDb(db);
  },
  async requestSmsPermission(): Promise<boolean> { return true; },
  async importHistory(onProgress: (done: number, total: number) => void): Promise<{ imported: number; unknown: number }> {
    onProgress(0, 0); return { imported: 0, unknown: 0 };
  },
  async syncNow(): Promise<{ pending: number }> { const pending = await this.pendingCount(); return { pending }; },
  async pendingCount(): Promise<number> {
    const db = getDb(); let count = 0;
    for (const [, row] of db) { if (row.type !== 'category' && row.type !== 'budget' && row.type !== 'rule' && row.synced === false) count++; }
    return count;
  },
};